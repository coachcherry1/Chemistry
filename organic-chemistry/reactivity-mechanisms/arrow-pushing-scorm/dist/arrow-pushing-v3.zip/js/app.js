/* app.js: the steps, their order, saving, scoring, and the pieces every
 * step is built from. The steps themselves are drawn by steps1.js (Parts 1
 * and 2) and steps2.js (Parts 3 and 4).
 *
 * Part 1  Energy and bonds: bond breaking is endothermic and bond making
 *         exothermic; homolytic and heterolytic; entropy; thermodynamically
 *         favorable; reading an energy diagram
 * Part 2  Nucleophiles and electrophiles
 * Part 3  The four patterns: nucleophilic attack, loss of a leaving group,
 *         proton transfer, carbocation rearrangement
 * Part 4  Combining the patterns: sequences and concerted steps
 * Part 5  Final check: the four patterns on reactions not seen before
 *
 * Only the four checkpoints and the final check are graded (first answer counts; a graded
 * arrow drawing counts on its first Check). Arrows, sorts and predictions
 * must be finished to move on but are never scored: a wrong one gets an
 * explanation and another try.
 */

var App = (function () {
  'use strict';

  /* Bump whenever the step list, a quiz pool or a scene changes: a save
     from an older build is then discarded and the student starts fresh. */
  var SCHEMA = 5;

  var PARTS = [
    { n: 1, name: 'Energy and bonds' },
    { n: 2, name: 'Nucleophiles and electrophiles' },
    { n: 3, name: 'The four patterns' },
    { n: 4, name: 'Putting them together' },
    { n: 5, name: 'Final check' },
    { n: 6, name: 'Results' }
  ];

  var STEPS = [
    { id: 'break', part: 1, kind: 'break', title: 'Breaking a bond takes energy',
      text: 'Bonding electrons sit low in energy. Predict first, then pull the H and the Cl apart with the slider, and let them bond again.' },
    { id: 'cleave', part: 1, kind: 'cleave', title: 'Homolytic or heterolytic?',
      text: 'A bond can break two ways. Play each one and watch where the two electrons of the bond go.' },
    { id: 'bonds', part: 1, kind: 'bonds', title: 'Bonds broken, bonds formed',
      text: 'Every bond broken takes energy in; every bond formed gives energy out. Click every bond that breaks, then every bond that forms.' },
    { id: 'entropy', part: 1, kind: 'entropy', title: 'Entropy: more ways to arrange',
      text: 'Entropy measures how many ways a system can be arranged. Play the expansion, then sort the reactions by the sign of ΔS for the system.' },
    { id: 'favor', part: 1, kind: 'favor', title: 'Exergonic or endergonic?',
      text: 'A reaction with ΔG < 0 is exergonic and thermodynamically favorable. Read each energy diagram: is it exergonic or endergonic?' },
    { id: 'dg', part: 1, kind: 'dg', title: 'Thermodynamically favorable: ΔG = ΔH − TΔS',
      text: 'ΔG = ΔH − TΔS. Both terms decide the sign of ΔG. Fill in the table for each combination of signs.' },
    { id: 'diagram', part: 1, kind: 'diagram', title: 'Reading an energy diagram',
      text: 'Play each reaction and watch the dot on its energy diagram. Then click every transition state and every intermediate.' },
    { id: 'quiz-A', part: 1, kind: 'quiz', quiz: 'A', title: 'Checkpoint 1', text: '' },

    { id: 'rich', part: 2, kind: 'rich', title: 'Electron-rich, electron-poor',
      text: 'Ionic reactions happen when an electron-rich atom meets an electron-poor one. Predict first, then compare two compounds.' },
    { id: 'sort', part: 2, kind: 'sort', title: 'Nucleophile or electrophile?',
      text: 'Sort every compound or ion by how it will react (Klein Table 6.3 and Problem 6.8). Na⁺, Li⁺ and K⁺ are spectator ions.' },
    { id: 'centres', part: 2, kind: 'centres', title: 'Find the centres',
      text: 'One molecule can have both kinds of centre. Click every nucleophilic centre, then every electrophilic centre.' },
    { id: 'quiz-B', part: 2, kind: 'quiz', quiz: 'B', title: 'Checkpoint 2', text: '' },

    { id: 'read', part: 3, kind: 'read', title: 'Reading a curved arrow',
      text: 'The tail of a curved arrow is where the electrons are; the head is where they go. Play it, then judge five drawings by Klein’s rules.' },
    { id: 'nuc', part: 3, kind: 'draw', scenes: ['brAttack', 'acylAttack'], fade: ['worked', 'given'], title: 'Pattern 1: nucleophilic attack',
      text: 'A nucleophile attacks an electrophile. The first one is worked for you: play it and say it in words. In the second, one arrow is given; draw the other.' },
    { id: 'lg', part: 3, kind: 'draw', scenes: ['brLoss', 'tetLoss'], fade: ['worked', 'given'], title: 'Pattern 2: loss of a leaving group',
      text: 'A bond breaks and its pair leaves with the leaving group. Watch the worked one, then finish the second (one arrow is given).' },
    { id: 'pt', part: 3, kind: 'draw', scenes: ['protKetone', 'deprotKetone', 'alkeneH3O'], fade: ['worked', 'given', null], title: 'Pattern 3: proton transfer',
      text: 'A proton moves from one atom to another, leaving its electrons behind. Watch the worked one, finish the second, then draw the third on your own.' },
    { id: 'stable', part: 3, kind: 'stable', title: 'Carbocation stability',
      text: 'Before the fourth pattern: which carbocations are most stable, and why? Put the four in order, from least to most stable.' },
    { id: 'shift', part: 3, kind: 'draw', scenes: ['shiftH', 'shiftMe'], fade: ['worked', 'tail'], hole: true, title: 'Pattern 4: carbocation rearrangement',
      text: 'An H or a CH₃ next door moves over, with its pair of electrons, to make a more stable carbocation. Watch the worked hydride shift, then draw the methyl shift.' },
    { id: 'rearrange', part: 3, kind: 'rearrange', mols: ['r1', 'r3', 'r6', 'r4', 'r5', 'r7'], title: 'Will it rearrange?',
      text: 'Klein’s steps: find the carbons next to the C⁺, look at the H and CH₃ groups on them, and ask whether moving one makes a more stable carbocation.' },
    { id: 'name', part: 3, kind: 'name',
      scenes: ['nAllylLoss', 'nAllylWater', 'nArenium', 'nTbuClLoss', 'nPhShift', 'nCyclize', 'nAllylShift', 'nOxDeprot'],
      title: 'Name the pattern', text: 'Read the curved arrows in each step and name its pattern (Klein 6.11 and 6.27).' },
    { id: 'recall', part: 3, kind: 'recall', scenes: ['shiftH', 'protKetone', 'brAttack', 'brLoss'], title: 'The four patterns, from memory',
      text: 'The four patterns are hidden for this step. From memory: pick the four patterns of arrow pushing, then name the pattern in each picture.' },
    { id: 'quiz-C', part: 3, kind: 'quiz', quiz: 'C', title: 'Checkpoint 3', text: '' },

    { id: 'sequence', part: 4, kind: 'sequence', chain: 'f631', title: 'One mechanism, four patterns',
      text: 'Klein’s Figure 6.31, shown below: four steps, one of each pattern. For each step, name the pattern, then draw its arrows.' },
    { id: 'concerted', part: 4, kind: 'concerted', title: 'Two patterns at once',
      text: 'Sometimes one step does two patterns at the same time: a concerted step. Draw both arrows, watch it, and say it in words.' },
    { id: 'seqread', part: 4, kind: 'seqread', title: 'A sequence of patterns',
      text: 'A mechanism is a sequence of patterns. Read each step’s arrows and name its pattern.' },
    { id: 'quiz-D', part: 4, kind: 'quiz', quiz: 'D', title: 'Checkpoint 4', text: '' },

    { id: 'quiz-E', part: 5, kind: 'quiz', quiz: 'E', title: 'Final check', text: '' },

    { id: 'results', part: 6, kind: 'results', title: 'Results', text: '' }
  ];

  /* Every prediction the steps ask, with its key. Predictions are never
     graded; tools/validate.js checks every key against the model. */
  var PREDICT = {
    breakE: { q: 'Pulling the two atoms of a bond apart is:', choices: ['Endothermic: the system takes in energy', 'Exothermic: the system gives out energy', 'Neither: no energy changes hands'], answer: 0 },
    spread: { q: 'Open the valve. Will the gas stay on one side, or spread into both?', choices: ['Spread into both, and stay spread', 'Stay on its side', 'Spread, then gather back on one side'], answer: 0 },
    poor: { q: 'Which carbon is electron-poor (δ+)?', choices: ['The C of chloromethane, CH₃Cl', 'The C of methyllithium, CH₃Li', 'Both equally'], answer: 0 },
    order3: { q: 'Which carbocation do you expect to be the most stable?', choices: ['Tertiary (3°)', 'Primary (1°)', 'Methyl', 'They are all the same'], answer: 0, compact: true },
    peak: { q: 'In the reaction of 2-bromo-2-methylpropane with Cl⁻, where does the carbocation sit on the energy diagram?',
      choices: ['In a valley: an intermediate', 'On a peak: a transition state', 'At the start, with the reactants'], answer: 0 }
  };

  var QZ = QUIZZES;
  var GRADED = Object.keys(QZ).reduce(function (s, k) { return s + QZ[k].draw; }, 0);

  var el = {};
  var state = null;
  var ctl = null;
  var preview = false;
  var RENDER = {};
  var reduceMotion = false;
  try { reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { /* old browser */ }

  var SC = SCENES.S;

  /* ---------------------------------------------------------------- helpers */

  function $(id) { return document.getElementById(id); }

  function h(tag, attrs, kids) {
    var n = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      var v = attrs[k];
      if (v == null || v === false) return;
      if (k === 'class') n.className = v;
      else if (k === 'text') n.textContent = v;
      else if (k.slice(0, 2) === 'on') n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v === true ? '' : v);
    });
    (kids || []).forEach(function (c) {
      if (c == null) return;
      n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
    return n;
  }

  function say(text, kind) {
    el.feedback.textContent = text || '';
    el.feedback.className = 'feedback' + (kind ? ' ' + kind : '');
  }

  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function hash(s) {
    var x = 2166136261;
    for (var i = 0; i < s.length; i++) { x ^= s.charCodeAt(i); x = Math.imul(x, 16777619); }
    return x >>> 0;
  }
  function shuffle(arr, rand) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(rand() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  function stepIndex(id) {
    for (var i = 0; i < STEPS.length; i++) if (STEPS[i].id === id) return i;
    return -1;
  }

  /* ------------------------------------------------------------------ state */

  /* A checkpoint's questions: the core, one from each pick group, then a
     random fill from the rest (never another member of a pick group). */
  function drawQuiz(Q, rand) {
    var ids = Q.core.slice();
    var grouped = [];
    (Q.pick || []).forEach(function (g) { grouped = grouped.concat(g); ids.push(g[Math.floor(rand() * g.length)]); });
    var rest = shuffle(Q.pool.map(function (q) { return q.id; }).filter(function (id) {
      return ids.indexOf(id) < 0 && grouped.indexOf(id) < 0;
    }), rand);
    ids = ids.concat(rest.slice(0, Q.draw - ids.length));
    return Q.pool.map(function (q) { return q.id; }).filter(function (id) { return ids.indexOf(id) >= 0; });
  }

  function newState() {
    var seed = Math.floor(Math.random() * 1e9);
    var rand = rng(seed);
    var draws = {};
    Object.keys(QZ).forEach(function (k) { draws[k] = drawQuiz(QZ[k], rand); });
    return { v: SCHEMA, seed: seed, step: 0, max: 0, draws: draws, ans: {}, pick: {}, fix: {}, qd: {}, pr: {}, done: {}, fin: 0, best: 0, att: 1 };
  }

  function restore(saved) {
    if (!saved || !saved.draws || saved.v !== SCHEMA) return null;
    var ok = Object.keys(QZ).every(function (k) {
      return (saved.draws[k] || []).length === QZ[k].draw && saved.draws[k].every(function (id) {
        return QZ[k].pool.some(function (q) { return q.id === id; });
      });
    });
    return ok ? saved : null;
  }

  function persist() { if (!preview) SCORM.saveState(state); }

  function correctCount() {
    return Object.keys(state.ans).reduce(function (s, k) { return s + (state.ans[k] ? 1 : 0); }, 0);
  }
  function attemptPercent() { return 100 * correctCount() / GRADED; }

  /* The gradebook gets the better of this attempt and the best finished
     one, so a new attempt can never lower a student's grade. */
  function reportScore() {
    if (preview) return;
    SCORM.setScore(Math.max(state.best || 0, attemptPercent()));
  }

  function newAttempt() {
    var keep = { best: Math.max(state.best || 0, state.fin ? attemptPercent() : 0), att: (state.att || 1) + 1, max: state.max };
    state = newState();
    state.best = keep.best;
    state.att = keep.att;
    state.max = keep.max;
    persist();
    reportScore();
    goTo(0);
  }

  function nav(name, prop, value) { el[name][prop] = value; el[name + 'Top'][prop] = value; }

  function complete(msg, kind) {
    var s = STEPS[state.step];
    state.done[s.id] = 1;
    if (state.step + 1 > state.max) state.max = state.step + 1;
    persist();
    nav('next', 'disabled', false);
    paintParts();
    if (msg) say(msg, kind || 'good');
  }

  function progress(id) {
    if (!state.pr[id]) state.pr[id] = {};
    return state.pr[id];
  }

  /* --------------------------------------------------------------- chrome */

  function paintParts() {
    el.parts.innerHTML = '';
    var cur = STEPS[state.step].part;
    PARTS.forEach(function (p) {
      var first = -1;
      for (var i = 0; i < STEPS.length; i++) if (STEPS[i].part === p.n) { first = i; break; }
      var open = first <= state.max;
      el.parts.appendChild(h('button', {
        type: 'button', class: 'tab' + (p.n === cur ? ' current' : '') + (open ? '' : ' locked'),
        disabled: !open, 'aria-current': p.n === cur ? 'step' : null,
        onclick: function () { if (open) goTo(first); }
      }, [p.n < PARTS.length ? p.n + '  ' + p.name : p.name]));
    });
    el.score.textContent = 'Checkpoint score: ' + correctCount() + ' / ' + GRADED +
      (state.att > 1 ? '  ·  best ' + Math.round(state.best || 0) + '%' : '');
  }

  function goTo(i) {
    if (i < 0 || i >= STEPS.length || i > state.max) return;
    if (ctl && ctl.destroy) ctl.destroy();
    ctl = null;
    state.step = i;
    persist();
    var s = STEPS[i];
    el.stepTitle.textContent = s.title;
    el.counter.textContent = 'Step ' + (i + 1) + ' of ' + STEPS.length;
    var text = s.kind === 'quiz' ? (s.quiz === 'E' ? 'New reactions, the same four patterns. ' : '') + 'Graded: your first answer to each question counts, and a drawing counts on its first Check. Read the explanation after each one.' : s.text;
    el.instructions.textContent = text;
    el.instructions.hidden = !text;
    el.stage.innerHTML = '';
    el.stage.className = 'stage stage-' + s.kind;
    /* retrieval: the four patterns' definitions are out of reach in the recall
       step and the final check (and in pattern questions, set per question) */
    document.body.classList.toggle('recall-mode', s.kind === 'recall' || (s.kind === 'quiz' && s.quiz === 'E'));
    say('');
    nav('next', 'disabled', !(state.done[s.id] || i < state.max));
    nav('next', 'hidden', s.kind === 'results');
    nav('next', 'textContent', STEPS[i + 1] && STEPS[i + 1].kind === 'results' ? 'See results →' : 'Next →');
    nav('back', 'hidden', i === 0);
    paintParts();
    ctl = RENDER[s.kind](s) || null;
    window.scrollTo(0, 0);
  }

  /* ------------------------------------------------------- shared pieces */

  function panel(title, hint, kids, cls) {
    return h('section', { class: 'panel ' + (cls || '') }, [
      h('div', { class: 'panel-head' }, [h('h3', { text: title }), hint ? h('span', { class: 'hint', text: hint }) : null])
    ].concat(kids || []));
  }

  function showArea(node) {
    try { node.scrollIntoView({ block: 'nearest', behavior: reduceMotion ? 'auto' : 'smooth' }); }
    catch (e) { node.scrollIntoView(false); }
  }

  function predictCard(p, chosen, onPick) {
    var box = h('div', { class: 'predict' }, [
      h('p', { class: 'predict-kicker', text: 'Predict (not graded)' }),
      h('p', { class: 'q-text', text: p.q })
    ]);
    var row = h('div', { class: 'q-choices' + (p.compact ? ' compact' : '') });
    p.choices.forEach(function (c, i) {
      var b = h('button', { type: 'button', class: 'choice' + (chosen === i ? ' picked' : ''), disabled: chosen != null },
        [h('span', { class: 'choice-text', text: c })]);
      b.addEventListener('click', function () { onPick(i); });
      row.appendChild(b);
    });
    box.appendChild(row);
    return box;
  }

  function reveal(lines) {
    return h('div', { class: 'reveal' }, lines.filter(Boolean).map(function (t) { return typeof t === 'string' ? h('p', { text: t }) : t; }));
  }

  function verdict(p, chosen) {
    if (chosen == null) return '';
    return chosen === p.answer ? 'Your prediction was right. ' : 'You predicted “' + p.choices[chosen] + '”. ';
  }

  /* A prediction in its panel, and the reveal after it. */
  function predictBox(p, pr, keyName, revealText, then) {
    var box = h('div');
    function paint() {
      box.innerHTML = '';
      box.appendChild(panel('Your prediction', null, [predictCard(p, pr[keyName], function (i) {
        pr[keyName] = i; persist(); paint(); if (then) then();
      })]));
      if (pr[keyName] != null) box.appendChild(reveal([verdict(p, pr[keyName]) + revealText]));
    }
    paint();
    return box;
  }

  function chipRow(label, items, cur, isDone, isOpen, onPick) {
    return h('div', { class: 'chips' }, [label ? h('span', { class: 'chips-label', text: label }) : null].concat(items.map(function (it, k) {
      return h('button', { type: 'button', class: 'chip' + (k === cur ? ' current' : '') + (isDone(k) ? ' done' : ''),
        disabled: !isOpen(k), 'aria-pressed': k === cur ? 'true' : 'false',
        onclick: function () { onPick(k); } }, [(isDone(k) ? '✓ ' : '') + it]);
    })));
  }

  function capFirst(t) { return t.charAt(0).toUpperCase() + t.slice(1); }
  function def(term, text) { return h('p', { class: 'def' }, [h('b', { text: term + ': ' }), text]); }

  /* A progress slider with a Play button. onInput(p) for every move. */
  function slider(onInput, o) {
    o = o || {};
    var range = h('input', { type: 'range', min: 0, max: 100, value: Math.round((o.p || 0) * 100), class: 'prog-range',
      'aria-label': o.label || 'Reaction progress' });
    var play = h('button', { type: 'button', class: 'mini play', text: '▶ Play' });
    var anim = null;
    range.addEventListener('input', function () { stop(); onInput(+range.value / 100); });
    function stop() { if (anim) { cancelAnimationFrame(anim); anim = null; play.textContent = '▶ Play'; } }
    play.addEventListener('click', function () {
      if (anim) { stop(); return; }
      if (+range.value >= 100) { range.value = 0; onInput(0); }
      if (reduceMotion) {
        /* no motion: still frames, one per press (at o.stops, or evenly spaced) */
        var stepN = o.frames || 4, next;
        if (o.stops) next = 100 * o.stops.filter(function (t) { return t * 100 > +range.value + 0.5; }).concat([1])[0];
        else next = Math.min(100, (Math.floor(+range.value * stepN / 100 + 1e-6) + 1) * 100 / stepN);
        range.value = next; onInput(next / 100);
        if (next >= 100 && o.done) o.done();
        return;
      }
      var start = null, from = +range.value, dur = o.ms || 3600;
      play.textContent = '❚❚ Pause';
      function step(ts) {
        if (start == null) start = ts;
        var v = Math.min(100, from + (ts - start) / dur * 100);
        range.value = v;
        onInput(v / 100);
        if (v < 100) anim = requestAnimationFrame(step);
        else { stop(); if (o.done) o.done(); }
      }
      anim = requestAnimationFrame(step);
    });
    var node = h('div', { class: 'range-row' }, [h('span', { text: o.from || 'Start' }), range, h('span', { text: o.to || 'Products' }), play]);
    return { node: node, set: function (p) { range.value = Math.round(p * 100); onInput(p); }, value: function () { return +range.value / 100; },
             stop: stop, range: range, play: play };
  }

  /* Names for bonds in the energy ledger: "C–Br", "C=O pi". */
  function bondName(st, b) {
    var A = Chem.atom(st, b.a), B = Chem.atom(st, b.b);
    /* C first (C–Br, C–H), else H first (H–Cl, H–O), as Klein writes them */
    var pair = [A.el, B.el];
    if (pair[1] === 'C' || (pair[1] === 'H' && pair[0] !== 'C')) pair.reverse();
    return pair.join(b.pi ? '=' : '–') + (b.pi ? ' pi bond' : ' bond');
  }

  /* The bonds a step breaks and makes, each with its energy, filled in as
     the animation reaches it. Returns { node, set(p) }. */
  function ledgerBox(sc, after) {
    var L = Chem.ledger(sc.before, after || sc.after);
    var rows = [];
    var list = h('ul', { class: 'ledger' });
    L.broken.forEach(function (b) {
      var li = h('li', { class: 'in' }, [h('span', { class: 'ledger-tag', text: 'energy in' }), bondName(sc.before, b) + ' broken: endothermic']);
      rows.push({ li: li, at: 0.3 }); list.appendChild(li);   /* its pair has left */
    });
    L.formed.forEach(function (b) {
      var li = h('li', { class: 'out' }, [h('span', { class: 'ledger-tag', text: 'energy out' }), bondName(after || sc.after, b) + ' formed: exothermic']);
      rows.push({ li: li, at: Render.BEATS.LAND }); list.appendChild(li);
    });
    function set(p) { rows.forEach(function (r) { r.li.classList.toggle('on', p >= r.at); }); }
    set(0);
    return { node: h('div', { class: 'ledger-box' }, [h('p', { class: 'ledger-head', text: 'Bonds broken and bonds made' }), list]), set: set };
  }

  /* A step's animation, its slider and its energy ledger. */
  function playerBox(sc, o) {
    o = o || {};
    var pl = Render.Player(sc, { scale: o.scale, ts: o.ts, arrows: o.arrows, picks: o.picks, after: o.after });
    var led = o.noLedger ? null : ledgerBox(sc, o.after);
    var B = Render.BEATS;
    var note = h('p', { class: 'beat-note', 'aria-live': 'off' });
    function beat(p) {
      note.textContent = p <= B.TAKEOFF ? 'The curved arrows' : p < B.LAND ? 'Each pair of electrons follows its arrow'
        : p < B.SETTLE ? 'The electrons have landed: new bonds, new charges' : 'The product of this step';
    }
    beat(0);
    var sl = slider(function (p) { pl.set(p); beat(p); if (led) led.set(p); if (o.onInput) o.onInput(p); },
      { from: 'Arrows', to: 'Products', ms: o.ms || 3400, done: o.done, stops: [0.3, B.LAND - 0.01, B.LAND + 0.04, 1] });
    var node = h('div', { class: 'player-box' }, [h('div', { class: 'mol-wrap anim' }, [pl.node]), note, sl.node, led ? led.node : null]);
    return { node: node, player: pl, slider: sl, ledger: led };
  }

  /* Show me, without an opt out: the right arrows appear in a still picture
     beside the drawing, the drawing is cleared, and the student draws them. */
  function showMe(sc, tool, yours) {
    tool.clear();
    yours.innerHTML = '';
    yours.appendChild(h('p', { class: 'muted', text: 'The right arrows. Copy them onto your drawing, then press Check:' }));
    yours.appendChild(h('div', { class: 'mol-wrap small' }, [Arrows.figure(sc, sc.arrows, { scale: 30, label: 'The right curved arrows' })]));
    yours.hidden = false;
  }

  /* An arrow-drawing exercise on one scene. done(fresh) is called once
     the arrows are right (now, or on a revisit).
     o.worked: a worked example (the arrows are drawn; the student plays it)
     o.given:  this many of the step's arrows are drawn for the student
     o.tail:   the tail of the first arrow is marked
     o.noProduct: do not draw the products beside the reactants (Figure 6.31's row already shows them)
     o.graded(r): called on the first Check with something drawn (graded) */
  function arrowBox(sc, pr, key, done, o) {
    o = o || {};
    var tool = Arrows.Tool(sc, { say: say, onCheck: check, scale: o.scale, checkText: o.checkText,
      given: o.given ? sc.arrows.slice(0, o.given) : null, tail: o.tail ? sc.arrows[0].from : null });
    var help = h('button', { type: 'button', class: 'ghostbtn', text: 'Show me', hidden: true });
    var yours = h('div', { class: 'yours', hidden: true });
    var legend = h('ol', { class: 'pattern-list', hidden: true });
    var note = o.worked ? h('p', { class: 'worked-note', text: 'Worked for you: these are the arrows. Play the step and watch the electrons follow them.' })
      : o.given ? h('p', { class: 'worked-note', text: (o.given === 1 ? 'The first arrow is drawn for you' : 'Some arrows are drawn for you') + ' (grey). Draw the rest.' })
      : o.tail ? h('p', { class: 'worked-note', text: 'The ringed electrons are where the arrow starts. Where do they go?' }) : null;
    /* The products are on screen before the arrows are asked for, as in the
       textbook: reactants, an arrow, products. */
    var prod = o.noProduct ? null : h('div', { class: 'product-fig' }, [h('p', { class: 'product-cap', text: 'Products' }),
      Render.draw(sc.after, { scale: 30, label: 'The products of this step' })]);
    var row = h('div', { class: 'arrow-row' });
    tool.node.insertBefore(row, tool.svg);
    row.appendChild(tool.svg);
    if (prod) {
      row.appendChild(h('span', { class: 'arrow-row-to', 'aria-hidden': 'true', text: '→' }));
      row.appendChild(prod);
    }
    var node = h('div', null, [note, tool.node, h('div', { class: 'btnrow' }, [help]), yours, legend]);
    function finish(fresh) {
      tool.lock();
      yours.hidden = true;
      legend.innerHTML = '';
      tool.legend().forEach(function (t) { if (t) legend.appendChild(h('li', { text: capFirst(t) + '.' })); });
      legend.hidden = false;
      help.hidden = true;
      if (done) done(fresh);
    }
    function check(r) {
      if (o.graded && !tool.drawn().length) { say(r.msg, 'bad'); return; }   /* nothing drawn: not an answer */
      var first = o.graded ? o.graded(r) : false;
      if (r.ok) {
        pr[key] = 1; persist();
        if (!o.graded) say(r.msg, 'good');
        finish(true);
        return;
      }
      pr[key + 'm'] = (pr[key + 'm'] || 0) + 1;
      persist();
      if (!o.graded) say(r.msg, 'bad');
      else say('Not quite: ' + r.msg + (first ? ' That first Check counted. Fix your arrows and press Check again.' : ''), 'bad');
      /* arrows that obey the rules but make something else: show it */
      yours.innerHTML = '';
      if (r.state) {
        yours.appendChild(h('p', { class: 'muted', text: 'Your arrows would make this instead:' }));
        yours.appendChild(h('div', { class: 'mol-wrap small' }, [Render.draw(r.state, { scale: 30, label: 'What your arrows would make' })]));
        yours.hidden = false;
      } else yours.hidden = true;
      if (pr[key + 'm'] >= (o.misses || 3)) help.hidden = false;
    }
    /* No opt out: Show me shows the arrows beside the drawing, and the
       student then draws them and checks. */
    help.addEventListener('click', function () {
      showMe(sc, tool, yours);
      say('These are the right arrows. Now draw them yourself, then press Check.', '');
    });
    if (pr[key] || o.worked) {
      tool.show(); finish(o.worked ? !pr[key] : false);
      if (o.worked && !pr[key]) { pr[key] = 1; persist(); }
    }
    else if (pr[key + 'm'] >= (o.misses || 3)) help.hidden = false;
    return { node: node, tool: tool };
  }

  /* Choice buttons that stay on screen once answered (ungraded). */
  function choiceRow(options, answer, chosen, onPick) {
    var row = h('div', { class: 'choice-row' });
    options.forEach(function (t, i) {
      var b = h('button', { type: 'button', class: 'ghostbtn' + (chosen != null && i === answer && chosen === answer ? ' right' : '') +
        (chosen === i && i !== answer ? ' wrong' : ''), text: t, disabled: chosen === answer });
      b.addEventListener('click', function () { onPick(i); });
      row.appendChild(b);
    });
    return row;
  }

  /* ------------------------------------------------------------- figures */

  /* Question figures: { mol: id } a drawing; { mech: id, rule } a step with
     its arrows (or a rule-breaking set from SCENES.RULES); { energy:
     profile, dG }; { chain: id } every step of a chain with its arrows. */
  function figure(spec) {
    if (spec.mech) {
      var sc = SC[spec.mech];
      var arrows = sc.arrows;
      if (spec.rule) arrows = SCENES.RULES.concat(SCENES.QUIZ_RULES).filter(function (r) { return r.id === spec.rule; })[0].arrows;
      return Arrows.figure(sc, arrows, { label: spec.label || sc.title + ' with curved arrows' });
    }
    if (spec.energy) {
      /* dG: true draws the ΔG bracket with its sign only, never the word the
         question may be asking for */
      return Energy.draw(SCENES.PROFILES[spec.energy], { dG: spec.dG ? ' ' : null, Ea: spec.Ea, mark: spec.mark, label: 'An energy diagram' });
    }
    if (spec.mols) {
      return h('div', { class: 'chain-fig' }, spec.mols.map(function (id) { return figure({ mol: id }); }));
    }
    if (spec.split || spec.bond) return FIG[spec.split ? 'split' : 'bond'](spec);
    if (spec.chain) {
      return h('div', { class: 'chain-fig' }, SC[spec.chain].map(function (sc, k) {
        return h('figure', null, [Arrows.figure(sc, sc.arrows, { scale: 30, label: 'Step ' + (k + 1) + ' with curved arrows' }), h('figcaption', { text: 'Step ' + (k + 1) })]);
      }));
    }
    if (spec.mol) {
      var m = SC[spec.mol];
      return h('figure', { class: 'mol-card' }, [Render.draw(m.before, { scale: 36, label: m.label || m.title }), h('figcaption', { text: m.label || m.title })]);
    }
    return h('div');
  }

  /* figures drawn by the step files (steps1.js): split, bond */
  var FIG = {};

  function figureText(spec) {
    if (spec.mech) return (SC[spec.mech].title || 'a step') + ', with curved arrows';
    if (spec.mol) return SC[spec.mol].title;
    return 'a drawing';
  }

  /* ------------------------------------------------------------- quizzes */

  function question(id) {
    for (var k in QZ) {
      var pool = QZ[k].pool;
      for (var i = 0; i < pool.length; i++) if (pool[i].id === id) return pool[i];
    }
    return null;
  }

  /* The reference beside a checkpoint (qualitative: no calculations). */
  function quizSide(k) {
    if (k === 'A') {
      return panel('Energy words', null, [h('dl', { class: 'vocab' }, [
        ['Bond breaking', 'Endothermic: energy in.'], ['Bond making', 'Exothermic: energy out.'],
        ['ΔG < 0', 'Exergonic, thermodynamically favorable, K > 1.'], ['ΔG > 0', 'Endergonic, not thermodynamically favorable, K < 1.'],
        ['ΔG = ΔH − TΔS', 'ΔS > 0: more molecules, or a ring opening.'],
        ['Peak', 'A transition state. Valley: an intermediate.'], ['Eₐ', 'The climb to the first peak: how fast.']
      ].reduce(function (acc, p) { acc.push(h('dt', { text: p[0] })); acc.push(h('dd', { text: p[1] })); return acc; }, []))], 'side');
    }
    /* The four patterns sit beside Checkpoints 3 and 4, but not while a
       question asks to name a pattern (retrieval, not matching the card),
       and never in the final check. */
    var pats = k === 'C' || k === 'D' ? h('div', { class: 'side-patterns' }, [h('h4', { text: 'The four patterns' }), patternsNode()]) : null;
    var gone = pats ? h('p', { class: 'muted side-gone', hidden: true, text: 'The four patterns are hidden for this question: name it from memory.' }) : null;
    return panel(k === 'B' || k === 'E' ? 'Klein Table 6.3' : 'Klein Table 6.3 and the four patterns', null, [tableNode(), pats, gone], 'side');
  }

  /* Does this question ask the student to name a pattern from memory? */
  function fromMemory(q) { return !!(q.recall || (q.check && (q.check.pattern || q.check.seq))); }

  function tableNode() {
    var rows = [['Hydroxide', 'NaOH'], ['Alkoxide ions', 'NaOR'], ['Halide ions', 'NaX (Cl, Br, I)'], ['Thiolate', 'NaSH'],
      ['Alkene', 'R₂C=CR₂'], ['Alcohol', 'ROH (weak)'], ['Water', 'H₂O (weak)']];
    var er = [['Alkyl halides', 'R–X (Cl, Br, I)'], ['Carbocations', 'C⁺'], ['Carbonyl groups', 'C=O']];
    return h('div', { class: 'grid2 tight' }, [
      h('table', { class: 'ref-table' }, [h('tr', null, [h('th', { text: 'Nucleophiles' }), h('th', { text: '' })])].concat(rows.map(function (r) {
        return h('tr', null, [h('td', { text: r[0] }), h('td', { text: r[1] })]);
      }))),
      h('table', { class: 'ref-table' }, [h('tr', null, [h('th', { text: 'Electrophiles' }), h('th', { text: '' })])].concat(er.map(function (r) {
        return h('tr', null, [h('td', { text: r[0] }), h('td', { text: r[1] })]);
      })))
    ]);
  }
  function patternsNode() {
    return h('dl', { class: 'vocab' }, [
      ['Nucleophilic attack', 'A lone pair or pi bond makes a new bond to an electrophile.'],
      ['Loss of a leaving group', 'A bond breaks; its pair leaves with the leaving group.'],
      ['Proton transfer', 'An H moves without its electrons: two arrows.'],
      ['Carbocation rearrangement', 'An H or CH₃ next door moves to the C⁺ with its pair.']
    ].reduce(function (acc, p) { acc.push(h('dt', { text: p[0] })); acc.push(h('dd', { text: p[1] })); return acc; }, []));
  }

  RENDER.quiz = function (s) {
    var Q = QZ[s.quiz];
    var ids = state.draws[s.quiz];
    var box = h('div', { class: 'quiz' });
    var sidePanel = quizSide(s.quiz);
    el.stage.appendChild(h('div', { class: 'quiz-grid' }, [panel(Q.title, null, [box]), sidePanel]));
    function side(q) {
      if (s.quiz === 'C' || s.quiz === 'D') document.body.classList.toggle('recall-mode', fromMemory(q));
      var p = sidePanel.querySelector('.side-patterns'), g = sidePanel.querySelector('.side-gone');
      if (!p) return;
      p.hidden = fromMemory(q);
      g.hidden = !p.hidden;
    }

    function summary() {
      box.innerHTML = '';
      var right = ids.filter(function (id) { return state.ans[id]; }).length;
      box.appendChild(h('p', { class: 'q-summary', text: 'You answered ' + right + ' of ' + ids.length + ' correctly on the first try.' }));
      var ul = h('ul', { class: 'q-review' });
      ids.forEach(function (id) {
        var q = question(id);
        ul.appendChild(h('li', { class: state.ans[id] ? 'right' : 'wrong' }, [
          h('span', { class: 'mark', 'aria-hidden': 'true', text: state.ans[id] ? '✓' : '✗' }),
          h('span', { class: 'sr', text: state.ans[id] ? 'Correct: ' : 'Incorrect: ' }),
          q.q
        ]));
      });
      box.appendChild(ul);
      if (!state.done[s.id]) complete('Checkpoint finished: ' + right + ' / ' + ids.length + '.', 'good');
      else say('Checkpoint finished: ' + right + ' / ' + ids.length + '.', 'good');
    }

    function record(id, right, letter) {
      state.ans[id] = right ? 1 : 0;
      persist();
      reportScore();
      if (!preview) SCORM.recordAnswer(id, letter, 'a', right);
      paintParts();
    }

    /* No opt out: a wrong answer counts as wrong, then the student keeps
       going until they produce the right one (state.fix marks that). */
    function settled(id) { return state.ans[id] === 1 || (state.ans[id] === 0 && state.fix[id]); }

    function ask(n) {
      var id = ids[n];
      if (id == null) { summary(); return; }
      if (settled(id)) { ask(n + 1); return; }
      var q = question(id);
      var redo = state.ans[id] === 0;          /* counted wrong, not yet put right */
      box.innerHTML = '';
      box.setAttribute('data-qid', id);
      say('');
      side(q);
      box.appendChild(h('p', { class: 'q-count', text: 'Question ' + (n + 1) + ' of ' + ids.length }));
      box.appendChild(h('p', { class: 'q-text', text: q.q }));
      var why = h('p', { class: 'q-why', hidden: true });
      var fb = h('p', { class: 'q-wrong', hidden: true, 'aria-live': 'polite' });
      var next = h('button', { type: 'button', class: 'primary', hidden: true, text: n + 1 < ids.length ? 'Next question →' : 'Finish checkpoint' });
      next.addEventListener('click', function () { ask(n + 1); });
      function fixed() {
        if (state.ans[id] === 0 && !state.fix[id]) { state.fix[id] = 1; persist(); }
        why.hidden = false;
        why.textContent = q.why;
        next.hidden = false;
        next.focus({ preventScroll: true });
      }

      if (q.draw) {
        /* a graded drawing: the first Check counts; then draw until right */
        var sc = SC[q.draw];
        var qpr = state.qd[id] = state.qd[id] || {};
        var ab = arrowBox(sc, qpr, 'a', function () {
          say(state.ans[id] === 1 ? 'Correct. These arrows are right.' : 'Now they are right. (Your first Check is the one that counted.)', 'good');
          fixed();
        }, { checkText: redo ? 'Check' : 'Check (graded)', graded: function (r) {
          if (state.ans[id] != null) return false;
          record(id, r.ok, r.ok ? 'a' : 'b');
          ab.tool.checkText('Check');
          return true;
        } });
        if (redo) say('This one counted as wrong. Draw the right arrows to go on.', 'bad');
        box.appendChild(h('div', { class: 'q-draw' }, [ab.node]));
        box.appendChild(why);
        box.appendChild(h('div', { class: 'btnrow' }, [next]));
        return;
      }

      var order = shuffle(q.choices.map(function (c, i) { return i; }), rng(state.seed ^ hash(id)));
      if (q.fig) box.appendChild(h('div', { class: 'q-fig' }, [figure(q.fig)]));
      var figs = typeof q.choices[0] !== 'string';
      var row = h('div', { class: 'q-choices' + (figs ? ' figs' : q.compact ? ' compact' : '') });
      order.forEach(function (ci, pos) {
        var c = q.choices[ci];
        var letter = String.fromCharCode(65 + pos);
        var b = h('button', { type: 'button', class: 'choice', 'data-choice': ci }, [
          h('span', { class: 'choice-letter', text: letter }),
          typeof c === 'string' ? h('span', { class: 'choice-text', text: c }) : figure(c)
        ]);
        if (typeof c !== 'string') b.setAttribute('aria-label', 'Choice ' + letter + ': ' + figureText(c));
        b.addEventListener('click', function () { if (state.ans[id] == null) choose(ci); else retry(ci); });
        row.appendChild(b);
      });
      box.appendChild(row);
      box.appendChild(fb);
      box.appendChild(why);
      /* Graded, so a click only selects; Submit answer grades it (the first submit counts). */
      var selCi = null;
      var submit = h('button', { type: 'button', class: 'primary submit-answer', disabled: true, text: 'Submit answer' });
      function choose(ci) {
        if (state.ans[id] != null) return;
        selCi = ci;
        var nodes = row.querySelectorAll('.choice');
        for (var i = 0; i < nodes.length; i++) {
          var on = +nodes[i].getAttribute('data-choice') === ci;
          nodes[i].classList.toggle('selected', on);
          nodes[i].setAttribute('aria-pressed', on ? 'true' : 'false');
        }
        submit.disabled = false;
      }
      submit.addEventListener('click', function () {
        if (selCi == null || state.ans[id] != null) return;
        if (submit.parentNode) submit.parentNode.removeChild(submit);
        var nodes = row.querySelectorAll('.choice');
        for (var i = 0; i < nodes.length; i++) { nodes[i].classList.remove('selected'); nodes[i].removeAttribute('aria-pressed'); }
        answer(selCi);
      });
      box.appendChild(h('div', { class: 'btnrow' }, [redo ? null : submit, next]));

      function mark(ci) {
        var nodes = row.querySelectorAll('.choice');
        for (var i = 0; i < nodes.length; i++) if (+nodes[i].getAttribute('data-choice') === ci) {
          nodes[i].classList.add(ci === 0 ? 'right' : 'wrong');
          nodes[i].disabled = true;
        }
      }
      function lockAll() {
        var nodes = row.querySelectorAll('.choice');
        for (var i = 0; i < nodes.length; i++) nodes[i].disabled = true;
      }
      /* each wrong choice has its own feedback: the misconception and the next move */
      function wrongText(ci) { return (q.wrong && q.wrong[ci - 1]) || ''; }
      function answer(ci) {
        if (state.ans[id] != null) return;
        var right = ci === 0;
        state.pick[id] = ci;
        record(id, right, String.fromCharCode(97 + ci));
        mark(ci);
        if (right) { lockAll(); say('Correct.', 'good'); fixed(); return; }
        fb.hidden = false;
        fb.textContent = wrongText(ci);
        say('Not quite. That answer counted. Read why, then pick the right answer.', 'bad');
      }
      /* after the counted answer: pick again (not graded) until right */
      function retry(ci) {
        if (settled(id)) return;
        mark(ci);
        if (ci === 0) {
          lockAll();
          fb.hidden = true;
          say('Now you have it. (Your first answer is the one that counted.)', 'good');
          fixed();
          return;
        }
        fb.hidden = false;
        fb.textContent = wrongText(ci);
        say('Not that one either. Read why, then pick again.', 'bad');
      }
      if (redo) {
        mark(state.pick[id]);
        fb.hidden = false;
        fb.textContent = wrongText(state.pick[id]);
        say('This one counted as wrong. Pick the right answer to go on.', 'bad');
      }
    }
    ask(0);
  };

  /* ---------------------------------------------------------------- results */

  var BIG_IDEAS = [
    'Bond breaking is endothermic (energy in) and bond making is exothermic (energy out). A step goes uphill or downhill depending on which wins.',
    'A reaction with ΔG < 0 is exergonic and thermodynamically favorable (K > 1); with ΔG > 0 it is endergonic and not thermodynamically favorable.',
    'On an energy diagram every peak is a transition state (partial bonds, never isolated) and every valley between peaks is an intermediate.',
    'Ionic reactions: an electron-rich nucleophile gives a pair of electrons to an electron-poor electrophile.',
    'A curved arrow moves one pair of electrons: the tail on a lone pair or a bond, never on a positive charge; the head on a new bond or a new lone pair; never a fifth bond to C, N or O.',
    'Every ionic mechanism combines four patterns: nucleophilic attack, loss of a leaving group, proton transfer and carbocation rearrangement.',
    'A carbocation rearranges (hydride or methyl shift) only when that makes a more stable carbocation: 3° > 2° > 1° > methyl, because alkyl groups are electron-donating.',
    'Two patterns in one step make a concerted step. Every mechanism is a sequence of the four patterns.'
  ];

  RENDER.results = function () {
    if (!state.fin) {
      state.fin = 1;
      state.done.results = 1;
      state.best = Math.max(state.best || 0, attemptPercent());
      persist();
      if (!preview) { reportScore(); SCORM.markComplete(); }
      paintParts();
    }
    var right = correctCount();
    var pct = Math.round(100 * right / GRADED);
    var best = Math.round(state.best || 0);
    var rows = Object.keys(QZ).map(function (k) {
      var ids = state.draws[k];
      var r = ids.filter(function (id) { return state.ans[id]; }).length;
      return h('tr', null, [h('td', { text: QZ[k].title }), h('td', { class: 'num', text: r + ' / ' + ids.length })]);
    });
    var box = panel(state.att > 1 ? 'Attempt ' + state.att : 'Your score', null, [
      h('p', { class: 'big-score', text: right + ' / ' + GRADED + '  (' + pct + '%)' }),
      h('table', { class: 'ref-table' }, rows),
      state.att > 1 ? h('p', { class: 'best-line', text: 'Best attempt: ' + best + '%' + (best > pct ? '. That is the score the gradebook keeps.' : '') }) : null,
      h('p', { class: 'muted', text: SCORM.isConnected()
        ? 'Your ' + (state.att > 1 ? 'best ' : '') + 'score has been sent to the gradebook and the activity is marked complete.'
        : 'Standalone mode: nothing was sent to a gradebook.' })
    ]);
    var ideas = panel('Big ideas', null, [h('ul', { class: 'keylist' }, BIG_IDEAS.map(function (t) { return h('li', { text: t }); }))]);
    el.stage.appendChild(h('div', { class: 'grid2' }, [box, ideas]));
    var again = h('button', { type: 'button', class: 'primary', text: 'Start a new attempt' });
    var sure = h('div', { class: 'confirm', hidden: true }, [
      h('p', { text: 'This clears all your answers, arrows and predictions and gives you a new set of checkpoint questions. ' +
                     'Your best score so far (' + Math.max(best, pct) + '%) stays in the gradebook.' }),
      h('div', { class: 'btnrow' }, [
        h('button', { type: 'button', class: 'primary', text: 'Yes, start again', onclick: newAttempt }),
        h('button', { type: 'button', class: 'ghostbtn', text: 'Cancel', onclick: function () { sure.hidden = true; again.hidden = false; again.focus(); } })
      ])
    ]);
    again.addEventListener('click', function () { again.hidden = true; sure.hidden = false; sure.querySelector('.primary').focus(); });
    el.stage.appendChild(panel('Try it again?', null, [
      h('p', { class: 'muted', text: 'You can redo the whole activity with new checkpoint questions. Parts you have already ' +
                                     'reached stay open, so you can jump straight to any of them.' }),
      h('div', { class: 'btnrow' }, [again]),
      sure
    ]));
    say('Activity complete.', 'good');
  };

  /* --------------------------------------------------------- references */

  var VOCAB = [
    ['Enthalpy (ΔH)', 'The heat exchanged with the surroundings. ΔH < 0 is exothermic (energy out); ΔH > 0 is endothermic (energy in).'],
    ['Bond dissociation energy', 'The energy it takes to break a bond homolytically. Breaking a bond is always endothermic; making it gives the same energy back out.'],
    ['Homolytic cleavage', 'A bond breaks evenly, one electron to each atom (two fish-hook arrows), making two radicals.'],
    ['Heterolytic cleavage', 'A bond breaks unevenly, both electrons to one atom (one curved arrow), making ions.'],
    ['Radical', 'An atom or molecule with an unpaired electron.'],
    ['Entropy (ΔS)', 'How many ways a system can be arranged. More molecules, or a ring opening, means ΔS > 0.'],
    ['Gibbs free energy (ΔG)', 'ΔG = ΔH − TΔS. ΔG < 0: thermodynamically favorable.'],
    ['Thermodynamically favorable', 'ΔG < 0: the products are favored at equilibrium (K > 1). Not thermodynamically favorable: ΔG > 0, K < 1.'],
    ['Exergonic, endergonic', 'Exergonic: ΔG < 0, products lower in free energy. Endergonic: ΔG > 0.'],
    ['Thermodynamics, kinetics', 'Thermodynamics (ΔG): which side is favored. Kinetics (Eₐ): how fast.'],
    ['Activation energy (Eₐ)', 'The climb from the reactants to the transition state.'],
    ['Transition state', 'A peak on an energy diagram: bonds partly broken and partly formed. It cannot be isolated. Drawn in brackets with ‡.'],
    ['Intermediate', 'A valley between peaks: a real species with a short lifetime, such as a carbocation.'],
    ['Ionic (polar) reaction', 'A reaction in which an electron-rich site meets an electron-poor one, through ions or polar bonds.'],
    ['Nucleophile', '“Nucleus lover”: electron-rich, gives a pair of electrons.'],
    ['Electrophile', '“Electron lover”: electron-poor, accepts a pair of electrons.'],
    ['Polarizability', 'How easily an atom’s electron cloud shifts. Large atoms (I, S) are polarizable: strong nucleophiles.'],
    ['Carbocation', 'A carbon with three bonds, a positive charge and an empty p orbital. 3° > 2° > 1° > methyl.'],
    ['Electron-donating group', 'A group that pushes electron density toward the atom it is bonded to, by induction. Alkyl groups are electron-donating, so each one on a C⁺ stabilizes it.'],
    ['Curved arrow', 'Moves one pair of electrons: tail on a lone pair or a bond, head on a new bond or lone pair.'],
    ['Fish-hook arrow', 'A curved arrow with half a head: moves one electron.'],
    ['Mechanism', 'The steps of a reaction, drawn with curved arrows.'],
    ['Nucleophilic attack', 'A nucleophile’s pair makes a new bond to an electrophile.'],
    ['Leaving group', 'The group that leaves with the pair of electrons of its bond.'],
    ['Loss of a leaving group', 'A bond breaks and its pair goes with the leaving group.'],
    ['Proton transfer', 'An H moves from one atom to another without its electrons. Two curved arrows.'],
    ['Carbocation rearrangement', 'A hydride shift (H) or methyl shift (CH₃) moves a group with its pair to the C⁺, making a more stable carbocation.'],
    ['Hydride shift', 'An H moves to the C⁺ next door with the pair of its bond (as H⁻, a hydride). A methyl shift moves a CH₃ the same way.'],
    ['Base', 'In a proton transfer, the one that takes the H (a proton, H⁺), with a lone pair or a pi bond.'],
    ['Concerted', 'Two patterns at the same time, in one step.']
  ];

  function buildReference() {
    el.patternsBody.appendChild(patternsNode());
    el.tableBody.appendChild(tableNode());
    var dl = h('dl', { class: 'vocab' });
    var PATS = ['Nucleophilic attack', 'Loss of a leaving group', 'Proton transfer', 'Carbocation rearrangement'];
    VOCAB.forEach(function (p) {
      var c = PATS.indexOf(p[0]) >= 0 ? 'vocab-pattern' : null;
      dl.appendChild(h('dt', { class: c, text: p[0] })); dl.appendChild(h('dd', { class: c, text: p[1] }));
    });
    el.vocabBody.appendChild(dl);
  }

  /* ------------------------------------------------------------------ boot */

  /* What this activity assumes (Klein chapters 1 to 3 and AP Chemistry). */
  var PREREQS = [
    'Draw a Lewis structure with every lone pair, and find an atom’s formal charge (Klein chapters 1 and 2).',
    'Mark δ+ and δ− on a polar bond from electronegativity.',
    'Call a carbon 1°, 2° or 3° by the number of carbons bonded to it.',
    'Know that a carbon with three bonds and a + charge has an empty p orbital (Klein chapter 1).',
    'Use ΔH, ΔS, ΔG and K as in AP Chemistry (no calculations here).'
  ];

  function showIntro() {
    var box = h('div', { class: 'screen-box', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'introTitle' }, [
      h('h2', { id: 'introTitle', text: 'Reactivity and Arrow Pushing' }),
      h('p', { text: 'Every ionic mechanism in this course is built from four patterns of curved arrows. By the end you will ' +
                     'draw the arrows for each one and name the pattern in any step you read (Klein, chapter 6).' }),
      h('ul', { class: 'screen-list' }, [
        h('li', { text: 'Part 1, Energy and bonds: breaking and making bonds, ΔG, energy diagrams.' }),
        h('li', { text: 'Part 2, Nucleophiles and electrophiles.' }),
        h('li', { text: 'Part 3, The four patterns, with curved arrows.' }),
        h('li', { text: 'Part 4, Putting the patterns together.' }),
        h('li', { text: 'Part 5, Final check: the same four patterns on reactions you have not seen.' })
      ]),
      h('p', { class: 'screen-kicker', text: 'Before you start, you should be able to:' }),
      h('ul', { class: 'prereq' }, PREREQS.map(function (t) { return h('li', { text: t }); })),
      h('p', { text: 'Arrows, sorts and predictions are never graded, so try things. The four checkpoints and the final check are graded: your ' +
                     'first answer to each question counts, and a drawing counts on its first Check. A wrong answer still has to be put right before you go on. ' +
                     'About 55 minutes. Your progress is saved if you leave.' }),
      h('p', { class: 'screen-note', text: 'Everything works with a mouse, a touch screen or the keyboard (Tab and Enter).' })
    ]);
    var go = h('button', { type: 'button', class: 'primary', text: state.max > 0 ? 'Continue where you left off' : 'Start' });
    box.appendChild(go);
    el.screen.innerHTML = '';
    el.screen.appendChild(box);
    el.screen.hidden = false;
    go.addEventListener('click', function () { el.screen.hidden = true; goTo(state.step); });
    go.focus();
  }

  function start() {
    ['parts', 'stepTitle', 'counter', 'instructions', 'stage', 'feedback', 'next', 'back', 'nextTop', 'backTop',
     'score', 'lms', 'screen', 'patternsBody', 'tableBody', 'vocabBody'].forEach(function (id) { el[id] = $(id); });
    buildReference();

    var connected = SCORM.init();
    el.lms.textContent = connected ? 'Connected to the LMS' : 'Standalone: no LMS detected';
    el.lms.className = 'lms ' + (connected ? 'on' : 'off');

    var params = new URLSearchParams(location.search);
    var jump = params.get('step');
    if (jump != null) {
      preview = true;
      state = newState();
      state.max = STEPS.length - 1;
      var idx = /^\d+$/.test(jump) ? +jump - 1 : stepIndex(jump);
      state.step = Math.max(0, Math.min(STEPS.length - 1, idx < 0 ? 0 : idx));
      /* teacher links: &all shows every question of the checkpoint's pool */
      if (params.has('all') && STEPS[state.step].quiz) {
        var k = STEPS[state.step].quiz;
        state.draws[k] = QZ[k].pool.map(function (q) { return q.id; });
      }
    } else {
      state = restore(SCORM.loadState()) || newState();
      persist();
    }

    [el.next, el.nextTop].forEach(function (b) { b.addEventListener('click', function () { goTo(state.step + 1); }); });
    [el.back, el.backTop].forEach(function (b) { b.addEventListener('click', function () { goTo(state.step - 1); }); });

    if (preview) { goTo(state.step); return; }
    paintParts();
    showIntro();
  }

  /* Everything the step files need. */
  var U = {
    h: h, say: say, panel: panel, capFirst: capFirst, predictCard: predictCard, predictBox: predictBox, reveal: reveal, verdict: verdict,
    chipRow: chipRow, def: def, slider: slider, playerBox: playerBox, ledgerBox: ledgerBox, arrowBox: arrowBox, bondName: bondName,
    choiceRow: choiceRow, showArea: showArea, shuffle: shuffle, rng: rng, hash: hash, figure: figure,
    complete: complete, progress: progress, persist: persist,
    stage: function () { return el.stage; },
    seed: function () { return state.seed; },
    isDone: function (id) { return !!state.done[id]; },
    reduceMotion: reduceMotion
  };

  return { start: start, SCHEMA: SCHEMA, STEPS: STEPS, GRADED: GRADED, QZ: QZ, PREDICT: PREDICT, RENDER: RENDER, U: U,
           BIG_IDEAS: BIG_IDEAS, VOCAB: VOCAB, figure: figure, drawQuiz: drawQuiz, FIG: FIG };
})();

document.addEventListener('DOMContentLoaded', App.start);
